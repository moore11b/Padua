﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace LabW11Authentication.Data.Migrations
{
    public partial class migpad1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsReported",
                table: "Devices",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsReported",
                table: "Devices");
        }
    }
}
