﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Claims;
using System.Threading.Tasks;
using LabW11Authentication.Models.ViewModels;
using LabW11Authentication.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace LabW11Authentication.Controllers
{

    /// <summary>
    /// This class exists to handle all user interaction.
    /// </summary>
    /// 
    [Authorize]
    public class UserController : Controller
    {
        private IUserRepository _repo;
        private IRoleRepository _repo2;
        public UserController(IUserRepository repo,
                              IRoleRepository repo2)
        {
            _repo = repo;
            _repo2 = repo2;
        }

        /// <summary>
        /// If account is admin, show all users and their roles.
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "Admin")]
        public IActionResult Index()
        {
            var user = _repo.Read(User.Identity.Name);
            if (!user.HasRole("Admin"))
            {
                return LocalRedirect("/Identity/Account/AccessDenied");
            }

            var users = _repo.ReadAll();
            var userList = users
               .Select(u => new UserListVM
               {
                   Email = u.User.Email,
                   UserName = u.User.UserName,
                   NumberOfRoles = u.Roles.Count,
                   UserId = u.User.Id
               });
            return View(userList);
        }

        /// <summary>
        /// If account is admin, show all device dbo data.
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "Admin")]
        public IActionResult DeviceList()
        {
            var user = _repo.Read(User.Identity.Name);
            if (!user.HasRole("Admin"))
            {
                return LocalRedirect("/Identity/Account/AccessDenied");
            }

            var devices = _repo.ReadAllDevices();
            var deviceList = devices
               .Select(u => new DeviceListVM
               {
                   Id = u.Id,
                   DevName = u.DevName,
                   DevMAC = u.DevMAC,
                   UserId = u.UserId,
                   IsReported = u.IsReported
               });
            return View(deviceList);
        }

        /// <summary>
        /// Pull all devices for current logged in user and pass to view for formatting.
        /// Must be logged in to view, validated in Identity
        /// </summary>
        /// <returns></returns>
        public IActionResult Devices()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var devices = _repo.ReadAllDevices();
            var deviceList = devices
               .Select(u => new DeviceListVM
               {
                   Id = u.Id,
                   DevName = u.DevName,
                   DevMAC = u.DevMAC,
                   UserId = u.UserId,
                   IsReported = u.IsReported
               });

            ViewBag.Message = userId;
            return View(deviceList);
        }

        /// <summary>
        /// If account is admin, change or assign new roles to users.
        /// </summary>
        /// <returns></returns>
        public IActionResult AssignRoles()
        {
            var user = _repo.Read(User.Identity.Name);
            if (!user.HasRole("Admin"))
            {
                return LocalRedirect("/Identity/Account/AccessDenied");
            }

            var users = _repo.ReadAll().Select(u => u.User.UserName).ToList();
            var roles = _repo2.ReadAll().Select(r => r.Name).ToList();
            var model = new AssignRoleVM
            {
                UserNames = users,
                RoleNames = roles
            };
            return View(model);
        }

        /// <summary>
        /// Submit role changes to DB (as admin editing accounts)
        /// </summary>
        /// <returns></returns>
        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult AssignRoles(AssignRoleVM model)
        {
            _repo.AssignRole(model.UserName, model.RoleName);
            return RedirectToAction("Index", "User");
        }

        /// <summary>
        /// only admin has access to manually create users
        /// </summary>
        /// <returns></returns>
        public IActionResult Create()
        {
            var user = _repo.Read(User.Identity.Name);
            if (!user.HasRole("Admin"))
            {
                return LocalRedirect("/Identity/Account/AccessDenied");
            }
            return View();
        }

        /// <summary>
        /// New user creation and verification of no conflicting user names.
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Create(CreateUserVM userVM)
        {
            var identityUser = new IdentityUser
            {
                Email = userVM.UserName,
                UserName = userVM.UserName
            };

            if (!_repo.Exists(identityUser.UserName))
            {
                ModelState.AddModelError("Username", "Username already exists!");
                return View(userVM);
            }

            await _repo.CreateAsync(identityUser, userVM.Password);

            return RedirectToAction("Index", "User");
        }

        /// <summary>
        /// add device to user account
        /// </summary>
        /// <returns></returns>
        public IActionResult AddDev()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (userId == null)
            {
                return View("Devices", "User");
            }
            ViewBag.Message = userId;
            return View();
        }

        /// <summary>
        /// New device addition and verification of no conflicting MAC addrs.
        /// </summary>
        /// <returns></returns>
        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult AddDev(AddDeviceVM deviceVM)
        {
            if (ModelState.IsValid)
            {
                var device = deviceVM.GetDevicesInstance();
                _repo.AddDev(device);
                return RedirectToAction("Devices", "User");
            }
            return View(deviceVM);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="personId"></param>
        /// <param name="recId"></param>
        /// <returns></returns>
        public IActionResult DeleteDevice([Bind(Prefix = "id")]int devId)
        {
            var device = _repo.ReadDeviceId(devId);
            //Modified to check the IsReported Status. 
            if (device == null || device.IsReported == true)
            {
                return RedirectToAction("Devices", "User");
            }
            return View(device);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="personId"></param>
        /// <returns></returns>
        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            _repo.DeleteDevice(id);
            return RedirectToAction("Devices", "User");
        }
        /// <summary>
        /// This method calls the service to change the Boolean IsReported Value, 
        /// then prompts to send an email to an admin. 
        /// The device page remains the same until refreshed, but deletion of the device is 
        /// not possible as the GET delete method was modified to check the "IsReported" status. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IActionResult DeviceReported(int id)
        {
            _repo.ReportDevice(id);
            return View();
        }

        [HttpPost]
        public ActionResult DeviceReported()
        {
            var user = _repo.Read(User.Identity.Name);
            string emailAddress = user.User.NormalizedEmail;
            try
            {
                if (ModelState.IsValid)
                {
                    // var receiverEmail = new MailAddress(emailAddress, user.User.NormalizedUserName);
                    var receiverEmail = new MailAddress(emailAddress, user.User.NormalizedUserName);
                    var senderEmail = new MailAddress("moore11b@gmail.com", "Cory");
                    var smtp = new SmtpClient
                    {
                        Host = "smtp.gmail.com",
                        Port = 587,
                        EnableSsl = true,
                        UseDefaultCredentials = false,
                        DeliveryMethod = SmtpDeliveryMethod.Network,
                        Credentials = new NetworkCredential("moore11b@gmail.com", "zxcvbnZXCVBN123456!@#$%^")
                    };
                    using (var messageToUser = new MailMessage(senderEmail, receiverEmail)
                    {
                        Subject = "Device Reported",
                        Body = "A device has been reported, we will notify you when it is found."
                    })
                    using (var messageToAdmin = new MailMessage(senderEmail, senderEmail)
                    {
                        Subject = "Device Reported",
                        Body = "A Device for " + user.User.UserName + " has been reported missing:\n"
                        +"\nPlease refer to logs for item MAC address."+
                        "A confirmation email has been sent to the user at " + user.User.NormalizedEmail+"."
                    })
                    {
                        smtp.Send(messageToUser);
                        smtp.Send(messageToAdmin);
                    }
                    return View();
                }
            }
            catch (Exception )
            {
                ViewBag.Error = "Make sure you have a valid email listed for your account..";
            }
            return View();
        }
    }
}